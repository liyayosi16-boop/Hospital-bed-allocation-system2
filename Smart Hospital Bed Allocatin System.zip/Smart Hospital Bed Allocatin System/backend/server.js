 const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const db = new sqlite3.Database('./ward.db');

app.use(cors());
app.use(express.json());

/* -------------------- TABLES -------------------- */

db.serialize(() => {

  db.run(`
    CREATE TABLE IF NOT EXISTS beds (
      id TEXT PRIMARY KEY,
      status TEXT,
      ward TEXT,
      patient TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      diagnosis TEXT,
      severity TEXT,
      arrivalTime INTEGER,
      status TEXT
    )
  `);
});

/* -------------------- LOGIN -------------------- */

app.post('/api/login', (req, res) => {

  const { username, password } = req.body;

  if (
    (username === 'doctor' || username === 'nurse')
    && password === '123'
  ) {
    return res.json({
      success: true,
      role: username
    });
  }

  return res.status(401).json({
    error: 'Invalid credentials'
  });
});

/* -------------------- PATIENTS -------------------- */

app.post('/api/patients/register', (req, res) => {

  const { name, diagnosis, severity } = req.body;

  db.run(
    `
    INSERT INTO patients
    (name, diagnosis, severity, arrivalTime, status)
    VALUES (?, ?, ?, ?, ?)
    `,
    [
      name,
      diagnosis,
      severity,
      Date.now(),
      'WAITING'
    ],
    function (err) {

      if (err) {
        return res.status(400).json({
          error: err.message
        });
      }

      res.json({
        success: true
      });
    }
  );
});

app.get('/api/patients/waiting', (req, res) => {

  db.all(
    `
    SELECT *
    FROM patients
    WHERE status='WAITING'
    `,
    [],
    (err, rows) => {

      if (err) {
        return res.status(500).json({
          error: err.message
        });
      }

      const priorityMap = {
        CRITICAL: 4,
        HIGH: 3,
        URGENT: 2,
        STABLE: 1
      };

      rows.sort((a, b) => {

        const severityDiff =
          priorityMap[b.severity] -
          priorityMap[a.severity];

        if (severityDiff !== 0) {
          return severityDiff;
        }

        return a.arrivalTime - b.arrivalTime;
      });

      res.json(rows);
    }
  );
});

/* -------------------- BEDS -------------------- */

app.get('/api/beds', (req, res) => {

  db.all(
    'SELECT * FROM beds',
    [],
    (err, rows) => {

      if (err) {
        return res.status(500).json({
          error: err.message
        });
      }

      const transformed = rows.map(bed => ({
        ...bed,
        label: bed.id,
        allocation: bed.ward
      }));

      res.json(transformed);
    }
  );
});

app.post('/api/beds/add', (req, res) => {

  const { id, ward } = req.body;

  db.run(
    `
    INSERT INTO beds
    (id,status,ward,patient)
    VALUES
    (?, 'AVAILABLE', ?, NULL)
    `,
    [id, ward],
    err => {

      if (err) {
        return res.status(400).json({
          error: err.message
        });
      }

      res.json({
        success: true
      });
    }
  );
});

app.post('/api/beds/assign', (req, res) => {

  const { id, patient } = req.body;

  db.run(
    `
    UPDATE beds
    SET status='OCCUPIED',
        patient=?
    WHERE id=?
    `,
    [patient, id],
    err => {

      if (err) {
        return res.status(400).json({
          error: err.message
        });
      }

      res.json({
        success: true
      });
    }
  );
});

/* -------------------- AUTO ASSIGN (GREEDY) -------------------- */

app.post('/api/beds/auto-assign', (req, res) => {

  db.all(
    `
    SELECT *
    FROM patients
    WHERE status='WAITING'
    `,
    [],
    (err, patients) => {

      if (err) {
        return res.status(500).json({
          error: err.message
        });
      }

      const priorityMap = {
        CRITICAL: 4,
        HIGH: 3,
        URGENT: 2,
        STABLE: 1
      };

      // GREEDY ALGORITHM
      patients.sort((a, b) => {

        const severityDiff =
          priorityMap[b.severity] -
          priorityMap[a.severity];

        if (severityDiff !== 0) {
          return severityDiff;
        }

        return a.arrivalTime - b.arrivalTime;
      });

      const patient = patients[0];
      console.log("PATIENT OBJECT:");
      console.log(patient);
      console.log("PATIENT:");
      console.log(patient);
      console.log("Diagnosis =", patient.diagnosis);
      console.log("Patient Name:", patient.name);
      console.log("Diagnosis:", patient.diagnosis);
      console.log("Severity:", patient.severity);

      if (!patient) {
        return res.json({
          message: 'No waiting patients'
        });
      }

      let requiredWard = 'General';

      switch (patient.diagnosis) {

        case 'Heart Attack':
          requiredWard = 'ICU';
          break;

        case 'Pediatric Pneumonia':
          requiredWard = 'Pediatrics';
          break;

        case 'Hernia Repair Post-Op':
          requiredWard = 'Surgical';
          break;

        case 'Kidney Infection':
          requiredWard = 'General';
          break;

        case 'Bone Fracture':
          requiredWard = 'Emergency';
          break;

        default:
          requiredWard = 'General';
      }
      console.log("Required Ward:", requiredWard);
      console.log("DIAGNOSIS =", patient.diagnosis);
      console.log("REQUIRED WARD =", requiredWard);

      db.get(
        `
        SELECT *
        FROM beds
        WHERE status='AVAILABLE'
        AND ward=?
        LIMIT 1
        `,
        [requiredWard],
        (err, bed) => {

          if (err) {
            return res.status(500).json({
              error: err.message
            });
          }

          if (!bed) {

            return res.json({
              message:
                'No available bed in ' +
                requiredWard +
                ' ward'
            });
          }

          db.run(
            `
            UPDATE beds
            SET
              status='OCCUPIED',
              patient=?
            WHERE id=?
            `,
            [patient.name, bed.id],
            (err) => {

              if (err) {
                return res.status(500).json({
                  error: err.message
                });
              }

              db.run(
                `
                UPDATE patients
                SET status='ADMITTED'
                WHERE id=?
                `,
                [patient.id],
                (err) => {

                  if (err) {
                    return res.status(500).json({
                      error: err.message
                    });
                  }

                  res.json({
                    success: true,
                    patient: patient.name,
                    ward: requiredWard,
                    bed: bed.id
                  });
                }
              );
            }
          );
        }
      );
    }
  );
});

 
/* -------------------- DISCHARGE -------------------- */

app.post('/api/beds/discharge/:id', (req, res) => {

  db.run(
    `
    UPDATE beds
    SET status='CLEANING'
    WHERE id=?
    `,
    [req.params.id],
    err => {

      if (err) {
        return res.status(400).json({
          error: err.message
        });
      }

      res.json({
        success: true
      });
    }
  );
});

/* -------------------- CLEANING -> AVAILABLE -------------------- */

app.post('/api/beds/available/:id', (req, res) => {

  db.run(
    `
    UPDATE beds
    SET
      status='AVAILABLE',
      patient=NULL
    WHERE id=?
    `,
    [req.params.id],
    err => {

      if (err) {
        return res.status(400).json({
          error: err.message
        });
      }

      res.json({
        success: true
      });
    }
  );
});

/* -------------------- DELETE -------------------- */

app.delete('/api/beds/delete/:id', (req, res) => {

  db.run(
    `
    DELETE FROM beds
    WHERE id=?
    `,
    [req.params.id],
    err => {

      if (err) {
        return res.status(400).json({
          error: err.message
        });
      }

      res.json({
        success: true
      });
    }
  );
});

app.listen(5000, () => {
  console.log('Server running on port 5000');
});