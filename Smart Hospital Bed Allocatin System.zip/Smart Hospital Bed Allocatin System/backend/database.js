 const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Locate or create the database file in the root backend directory
const dbPath = path.resolve(__dirname, 'ward.db');

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error connecting to the SQLite database:', err.message);
    } else {
        console.log('Connected to the SQLite database successfully.');
    }
});

// Initialize table schemas synchronously
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS beds (
        id TEXT PRIMARY KEY, 
        status TEXT, 
        ward TEXT, 
        patient TEXT
    )`, (err) => {
        if (err) {
            console.error('Error creating beds table:', err.message);
        } else {
            console.log('Beds table verified/initialized.');
        }
    });
});

module.exports = db;