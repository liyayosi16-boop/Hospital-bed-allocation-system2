import { Link, useNavigate } from 'react-router-dom';

export default function Sidebar() {
  const navigate = useNavigate();

  const menuItems = [
    { name: '📊 Dashboard', path: '/dashboard' },
    { name: '🛏 Ward Management', path: '/ward' },
    { name: '🗂 Patient Directory', path: '/patients' },
  ];

  return (
    <div style={{
      width: '240px',
      background: '#043927', // Your matching clean deep green
      color: '#fff',
      display: 'flex',
      flexDirection: 'column',
      padding: '20px 15px',
      boxSizing: 'border-box'
    }}>
      <h2 style={{ fontSize: '18px', margin: '0 0 30px 0', letterSpacing: '0.5px' }}>Smart Bed OS</h2>
      
      <nav style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1 }}>
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            style={{
              color: '#fff',
              textDecoration: 'none',
              padding: '12px 15px',
              borderRadius: '6px',
              fontSize: '14px',
              background: window.location.pathname === item.path ? '#00a859' : 'transparent',
              transition: 'background 0.2s'
            }}
          >
            {item.name}
          </Link>
        ))}
      </nav>

      <button 
        onClick={() => navigate('/')}
        style={{
          background: 'rgba(255,255,255,0.1)',
          color: '#fff',
          border: 'none',
          padding: '10px',
          borderRadius: '6px',
          cursor: 'pointer',
          fontWeight: 'bold'
        }}
      >
        🚪 Log Out
      </button>
    </div>
  );
}