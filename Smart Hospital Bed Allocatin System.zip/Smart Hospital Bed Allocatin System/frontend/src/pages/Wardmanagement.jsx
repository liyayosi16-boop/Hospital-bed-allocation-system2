  import { useState, useEffect } from 'react';

export default function WardManagement() {
  const [beds, setBeds] = useState([]);
  const [newId, setNewId] = useState('');
  const [newWard, setNewWard] = useState('ICU');
  const [patientInputs, setPatientInputs] = useState({});

  const [filterWard, setFilterWard] = useState('ALL');
  const [searchBed, setSearchBed] = useState('');

  const fetchData = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/beds');
      const data = await res.json();
      setBeds(data);
    } catch (err) {
      console.error("Error fetching bed data:", err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const addBed = async () => {
    if (!newId) return;

    await fetch('http://localhost:5000/api/beds/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: newId,
        ward: newWard
      })
    });

    setNewId('');
    fetchData();
  };

  const handleAssign = async (id) => {
    if (!patientInputs[id]) return;

    await fetch('http://localhost:5000/api/beds/assign', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id,
        patient: patientInputs[id]
      })
    });

    fetchData();
  };

  const autoAssign = async () => {
    await fetch(
      'http://localhost:5000/api/beds/auto-assign',
      {
        method: 'POST'
      }
    );

    fetchData();
  };

  const discharge = async (id) => {
    await fetch(
      `http://localhost:5000/api/beds/discharge/${id}`,
      {
        method: 'POST'
      }
    );

    fetchData();
  };

  const markAvailable = async (id) => {
    await fetch(
      `http://localhost:5000/api/beds/available/${id}`,
      {
        method: 'POST'
      }
    );

    fetchData();
  };

  const deleteBed = async (id) => {
    await fetch(
      `http://localhost:5000/api/beds/delete/${id}`,
      {
        method: 'DELETE'
      }
    );

    fetchData();
  };

  const filteredBeds = beds.filter((bed) => {

    const wardMatch =
      filterWard === 'ALL'
        ? true
        : bed.ward === filterWard;

    const searchMatch =
      bed.id
        .toLowerCase()
        .includes(searchBed.toLowerCase());

    return wardMatch && searchMatch;
  });

  return (
    <div style={{ padding: '20px' }}>

      <h1 style={{ color: '#043927' }}>
        Ward Management
      </h1>

      <h3>
        Total Registered Beds: {beds.length}
      </h3>

      {/* Controls */}

      <div
        style={{
          display: 'flex',
          gap: '10px',
          flexWrap: 'wrap',
          marginBottom: '20px'
        }}
      >
        <button
          onClick={autoAssign}
          style={{
            background: '#043927',
            color: '#fff',
            border: 'none',
            padding: '10px 15px',
            borderRadius: '6px',
            cursor: 'pointer'
          }}
        >
          Auto Assign Patient
        </button>

        <select
          value={filterWard}
          onChange={(e) =>
            setFilterWard(e.target.value)
          }
        >
          <option value="ALL">ALL</option>
          <option value="ICU">ICU</option>
          <option value="Emergency">Emergency</option>
          <option value="Pediatrics">Pediatrics</option>
          <option value="Surgical">Surgical</option>
          <option value="General">General</option>
        </select>

        <input
          placeholder="Search Bed ID"
          value={searchBed}
          onChange={(e) =>
            setSearchBed(e.target.value)
          }
        />
      </div>

      {/* Add Bed */}

      <div
        style={{
          marginBottom: '25px',
          display: 'flex',
          gap: '10px'
        }}
      >
        <input
          value={newId}
          onChange={(e) =>
            setNewId(e.target.value)
          }
          placeholder="BED-001"
        />

        <select
          value={newWard}
          onChange={(e) =>
            setNewWard(e.target.value)
          }
        >
          <option value="ICU">ICU</option>
          <option value="Emergency">Emergency</option>
          <option value="Pediatrics">Pediatrics</option>
          <option value="Surgical">Surgical</option>
          <option value="General">General</option>
        </select>

        <button onClick={addBed}>
          Add Bed
        </button>
      </div>

      {/* Bed Cards */}

      <div
        style={{
          display: 'grid',
          gridTemplateColumns:
            'repeat(auto-fill,minmax(220px,1fr))',
          gap: '15px'
        }}
      >
        {filteredBeds.map((bed) => {

          let bg = '#d4edda';

          if (bed.status === 'OCCUPIED') {
            bg = '#f8d7da';
          }

          if (bed.status === 'CLEANING') {
            bg = '#fff3cd';
          }

          return (
            <div
              key={bed.id}
              style={{
                background: bg,
                border: '2px solid #555',
                borderRadius: '10px',
                padding: '15px'
              }}
            >
              <h3>{bed.id}</h3>

              <p>
                <strong>Ward:</strong> {bed.ward}
              </p>

              <p>
                <strong>Status:</strong> {bed.status}
              </p>

              <p>
                <strong>Patient:</strong>{' '}
                {bed.patient || 'None'}
              </p>

              <div
                style={{
                  marginTop: '10px'
                }}
              >

                {bed.status === 'AVAILABLE' && (
                  <>
                    <input
                      placeholder="Patient Name"
                      value={
                        patientInputs[bed.id] || ''
                      }
                      onChange={(e) =>
                        setPatientInputs({
                          ...patientInputs,
                          [bed.id]:
                            e.target.value
                        })
                      }
                    />

                    <button
                      onClick={() =>
                        handleAssign(bed.id)
                      }
                      style={{
                        marginLeft: '5px'
                      }}
                    >
                      Assign
                    </button>
                  </>
                )}

                {bed.status === 'OCCUPIED' && (
                  <button
                    onClick={() =>
                      discharge(bed.id)
                    }
                  >
                    Discharge
                  </button>
                )}

                {bed.status === 'CLEANING' && (
                  <button
                    onClick={() =>
                      markAvailable(bed.id)
                    }
                  >
                    Mark Available
                  </button>
                )}

                <button
                  onClick={() =>
                    deleteBed(bed.id)
                  }
                  style={{
                    marginLeft: '10px',
                    background: '#ffcccc',
                    color: '#c00'
                  }}
                >
                  Delete
                </button>

              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
}