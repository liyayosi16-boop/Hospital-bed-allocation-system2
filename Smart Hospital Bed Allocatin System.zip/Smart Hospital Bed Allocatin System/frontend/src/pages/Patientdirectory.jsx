 import { useState, useEffect } from 'react';

export default function PatientDirectory() {
  const [waitingList, setWaitingList] = useState([]);
  const [admittedList, setAdmittedList] = useState([]);
  const [viewTab, setViewTab] = useState('waiting');
  const [newName, setNewName] = useState('');
  const [newSeverity, setNewSeverity] = useState('CRITICAL');
  const [newDiagnosis, setNewDiagnosis] = useState('Heart Attack'); // Baseline choice selection

  // Clean, singular array containing exactly your 5 custom presentation disease criteria
  const diseaseList = [
    "Heart Attack",
    "Bone Fracture",
    "Pediatric Pneumonia",
    "Hernia Repair Post-Op",
    "Kidney Infection"
  ];

  const refreshData = async () => {
    try {
      const resQueue = await fetch('http://localhost:5000/api/patients/waiting');
      const queueData = await resQueue.json();
      setWaitingList(queueData);

      const resBeds = await fetch('http://localhost:5000/api/beds');
      const bedData = await resBeds.json();
      
      const admitted = bedData.filter(b => b.status === 'OCCUPIED' && b.patient !== 'None').map(b => ({
        id: b.id, name: b.patient, bed: b.label, severity: b.severity, diagnosis: b.diagnosis, ward: b.allocation
      }));
      setAdmittedList(admitted);
    } catch (err) { console.error(err); }
  };

  useEffect(() => { refreshData(); }, []);

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!newName) return alert('Please input patient name');

    try {
      const res = await fetch('http://localhost:5000/api/patients/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName, severity: newSeverity, diagnosis: newDiagnosis })
      });
      if (res.ok) {
        setNewName('');
        refreshData();
        setViewTab('waiting');
      }
    } catch (err) { alert('Communication error with backend'); }
  };

  return (
    <div style={{ fontFamily: 'sans-serif' }}>
      <h1 style={{ color: '#043927', fontSize: '24px', marginBottom: '20px' }}>Clinical Patient Directory</h1>
      
      <div style={{ display: 'flex', gap: '10px', marginBottom: '25px', borderBottom: '2px solid #eee', paddingBottom: '12px' }}>
        <button onClick={() => setViewTab('waiting')} style={{ padding: '10px 20px', background: viewTab === 'waiting' ? '#043927' : '#eee', color: viewTab === 'waiting' ? '#fff' : '#333', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}>
          ⏳ Waiting List ({waitingList.length})
        </button>
        <button onClick={() => setViewTab('admitted')} style={{ padding: '10px 20px', background: viewTab === 'admitted' ? '#043927' : '#eee', color: viewTab === 'admitted' ? '#fff' : '#333', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}>
          ✅ Admitted Patients ({admittedList.length})
        </button>
      </div>

      <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
        <div style={{ flex: 2, background: '#fff', padding: '15px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
          {viewTab === 'waiting' ? (
            <div>
              <h3 style={{ marginTop: '0', color: '#c0392b' }}>Triage Priority Sorting Queue</h3>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                <thead>
                  <tr style={{ background: '#fafafa', borderBottom: '2px solid #eee' }}>
                    <th style={{ padding: '10px', textAlign: 'left' }}>RANK</th>
                    <th style={{ padding: '10px', textAlign: 'left' }}>PATIENT NAME</th>
                    <th style={{ padding: '10px', textAlign: 'left' }}>DIAGNOSIS</th>
                    <th style={{ padding: '10px', textAlign: 'left' }}>CARE SEVERITY</th>
                  </tr>
                </thead>
                <tbody>
                  {waitingList.map((p, index) => (
                    <tr key={p.id} style={{ borderBottom: '1px solid #eee' }}>
                      <td style={{ padding: '10px', fontWeight: 'bold', color: '#e74c3c' }}>#{index + 1}</td>
                      <td style={{ padding: '10px', fontWeight: 'bold' }}>{p.name}</td>
                      <td style={{ padding: '10px', color: '#34495e', fontWeight: '500' }}>{p.diagnosis}</td>
                      <td style={{ padding: '10px', color: '#f39c12', fontWeight: 'bold' }}>{p.severity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div>
              <h3 style={{ marginTop: '0', color: '#043927' }}>Active Admissions Tracking</h3>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                <thead>
                  <tr style={{ background: '#fafafa', borderBottom: '2px solid #eee' }}>
                    <th style={{ padding: '10px', textAlign: 'left' }}>PATIENT NAME</th>
                    <th style={{ padding: '10px', textAlign: 'left' }}>DIAGNOSIS</th>
                    <th style={{ padding: '10px', textAlign: 'left' }}>ASSIGNED LOCATION</th>
                  </tr>
                </thead>
                <tbody>
                  {admittedList.map((p) => (
                    <tr key={p.id} style={{ borderBottom: '1px solid #eee' }}>
                      <td style={{ padding: '10px' }}><strong>{p.name}</strong></td>
                      <td style={{ padding: '10px', color: '#34495e' }}>{p.diagnosis}</td>
                      <td style={{ padding: '10px', fontWeight: 'bold', color: '#043927' }}>{p.bed} ({p.ward} Ward)</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* REGISTRATION FORM PANEL */}
        <div style={{ flex: 1, background: '#fff', padding: '15px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)', height: 'fit-content' }}>
          <h3 style={{ marginTop: '0', color: '#043927' }}>Register New Case</h3>
          <form onSubmit={handleRegister}>
            <div style={{ marginBottom: '12px' }}>
              <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#555' }}>PATIENT NAME</label>
              <input type="text" placeholder="Ex: Chala" value={newName} onChange={(e) => setNewName(e.target.value)} style={{ width: '100%', padding: '8px', marginTop: '4px', boxSizing: 'border-box' }} />
            </div>
            
            <div style={{ marginBottom: '12px' }}>
              <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#555' }}>DIAGNOSIS</label>
              <select value={newDiagnosis} onChange={(e) => setNewDiagnosis(e.target.value)} style={{ width: '100%', padding: '8px', marginTop: '4px' }}>
                {diseaseList.map((disease) => (
                  <option key={disease} value={disease}>
                    {disease}
                  </option>
                ))}
              </select>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#555' }}>TRIAGE LEVEL</label>
              <select value={newSeverity} onChange={(e) => setNewSeverity(e.target.value)} style={{ width: '100%', padding: '8px', marginTop: '4px' }}>
                <option value="CRITICAL">CRITICAL</option>
                <option value="HIGH">HIGH</option>
                <option value="URGENT">URGENT</option>
                <option value="STABLE">STABLE</option>
              </select>
            </div>

            <button type="submit" style={{ width: '100%', background: '#043927', color: '#fff', padding: '10px', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}>
              Add to Waiting List
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}