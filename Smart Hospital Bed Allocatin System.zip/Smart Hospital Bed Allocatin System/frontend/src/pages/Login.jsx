 import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    
    // Ensure this port (5000) matches the port your server.js uses!
    const API_URL = 'http://localhost:5000/api/login';

    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      
      const data = await res.json();

      if (res.ok) {
        localStorage.setItem('staffRole', data.role);
        navigate('/dashboard'); 
      } else {
        alert(data.error || 'Login failed. Please check your credentials.');
      }
    } catch (err) {
      console.error("Connection error:", err);
      alert('Authentication channel offline. Please ensure your backend server (server.js) is running on port 5000.');
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#043927', justifyContent: 'center', alignItems: 'center', fontFamily: 'sans-serif' }}>
      <form onSubmit={handleLoginSubmit} style={{ background: '#fff', padding: '40px', borderRadius: '12px', width: '320px', boxShadow: '0 8px 16px rgba(0,0,0,0.2)' }}>
        <h2 style={{ textAlign: 'center', color: '#043927', margin: '0 0 10px 0' }}>Clinical Gateway</h2>
        <p style={{ textAlign: 'center', color: '#666', fontSize: '13px', marginBottom: '25px' }}>Authorized Clinician Login Only</p>
        
        <div style={{ marginBottom: '15px' }}>
          <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#555' }}>STAFF USERNAME</label>
          <input 
            type="text" 
            placeholder="Ex: doctor or nurse" 
            value={username} 
            onChange={(e) => setUsername(e.target.value)} 
            style={{ width: '100%', padding: '10px', marginTop: '6px', boxSizing: 'border-box', border: '1px solid #ccc', borderRadius: '4px' }} 
            required
          />
        </div>

        <div style={{ marginBottom: '25px' }}>
          <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#555' }}>ACCESS PASSWORD</label>
          <input 
            type="password" 
            placeholder="••••" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            style={{ width: '100%', padding: '10px', marginTop: '6px', boxSizing: 'border-box', border: '1px solid #ccc', borderRadius: '4px' }} 
            required
          />
        </div>

        <button type="submit" style={{ width: '100%', background: '#043927', color: '#fff', padding: '12px', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px' }}>
          Verify Credentials
        </button>
      </form>
    </div>
  );
}