 import { useState, useEffect } from 'react';

export default function Dashboard() {
  const [beds, setBeds] = useState([]);
  const [waitingList, setWaitingList] = useState([]);
  const [activeDropdown, setActiveDropdown] = useState('All');

  const fetchSystemData = async () => {
    try {
      const resBeds = await fetch('http://localhost:5000/api/beds');
      const bedData = await resBeds.json();
      setBeds(bedData);

      const resQueue = await fetch('http://localhost:5000/api/patients/waiting');
      const queueData = await resQueue.json();
      setWaitingList(queueData);
    } catch (err) {
      console.error("Dashboard synchronization drop:", err);
    }
  };

  useEffect(() => {
    fetchSystemData();
    const interval = setInterval(fetchSystemData, 2500);
    return () => clearInterval(interval);
  }, []);

  const totalBedsCount = beds.length || 20;
  const occupiedCount = beds.filter(b => b.status === 'OCCUPIED').length;
  const cleaningCount = beds.filter(b => b.status === 'CLEANING').length;
  const availableCount = beds.filter(b => b.status === 'AVAILABLE').length;
  const occupancyPercentage = Math.round((occupiedCount / totalBedsCount) * 100);

  const visibleBeds = activeDropdown === 'All' ? beds : beds.filter(b => b.allocation === activeDropdown);

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '10px' }}>
      <h1 style={{ color: '#043927', fontSize: '26px', margin: '0 0 25px 0', borderBottom: '3px solid #043927', paddingBottom: '10px' }}>
        Smart Bed Management System
      </h1>

      {/* TWO-COLUMN SIDE-BY-SIDE MAIN ROW WRAPPER */}
      <div style={{ display: 'flex', gap: '30px', alignItems: 'flex-start', flexWrap: 'wrap', marginBottom: '35px' }}>
        
        {/* LEFT COLUMN: 3 STATS BOXES STACKED neatly to leave clear space */}
        <div style={{ flex: '1', display: 'flex', flexDirection: 'column', gap: '15px', maxWidth: '320px' }}>
          <div style={{ background: '#fff', borderLeft: '8px solid #e74c3c', borderRadius: '8px', padding: '15px', boxShadow: '0 4px 6px rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#777', textTransform: 'uppercase' }}>Occupied Percentage</div>
            <div style={{ fontSize: '32px', fontWeight: '900', color: '#e74c3c', marginTop: '5px' }}>{occupancyPercentage}%</div>
          </div>

          <div style={{ background: '#fff', borderLeft: '8px solid #f39c12', borderRadius: '8px', padding: '15px', boxShadow: '0 4px 6px rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#777', textTransform: 'uppercase' }}>Beds In Sanitation</div>
            <div style={{ fontSize: '32px', fontWeight: '900', color: '#f39c12', marginTop: '5px' }}>{cleaningCount}</div>
          </div>

          <div style={{ background: '#fff', borderLeft: '8px solid #2ecc71', borderRadius: '8px', padding: '15px', boxShadow: '0 4px 6px rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#777', textTransform: 'uppercase' }}>Available Units</div>
            <div style={{ fontSize: '32px', fontWeight: '900', color: '#2ecc71', marginTop: '5px' }}>{availableCount}</div>
          </div>
        </div>

        {/* RIGHT COLUMN: EMBEDDED REAL-TIME WAITING LIST QUEUE */}
        <div style={{ flex: '2', minWidth: '400px', background: '#fff', padding: '20px', borderRadius: '10px', boxShadow: '0 4px 10px rgba(0,0,0,0.05)', alignSelf: 'stretch' }}>
          <h3 style={{ margin: '0 0 15px 0', color: '#c0392b', fontSize: '16px' }}>⏳ Active Patient Triage Queue ({waitingList.length})</h3>
          <div style={{ maxHeight: '180px', overflowY: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '13px' }}>
              <thead>
                <tr style={{ background: '#fafafa', color: '#666', borderBottom: '2px solid #eee' }}>
                  <th style={{ padding: '8px' }}>RANK</th>
                  <th style={{ padding: '8px' }}>NAME</th>
                  <th style={{ padding: '8px' }}>SEVERITY</th>
                </tr>
              </thead>
              <tbody>
                {waitingList.map((p, index) => (
                  <tr key={p.id} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '8px', fontWeight: 'bold', color: '#e74c3c' }}>#{index + 1}</td>
                    <td style={{ padding: '8px', fontWeight: 'bold' }}>{p.name}</td>
                    <td style={{ padding: '8px', color: '#f39c12', fontWeight: 'bold' }}>{p.severity}</td>
                  </tr>
                ))}
                {waitingList.length === 0 && (
                  <tr><td colSpan="3" style={{ padding: '15px', textAlign: 'center', color: '#aaa' }}>No entries in priority queue.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* RESOURCE MAP BAR */}
      <div style={{ background: '#fff', padding: '20px', borderRadius: '10px', boxShadow: '0 4px 10px rgba(0,0,0,0.05)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px', borderBottom: '1px solid #eee', paddingBottom: '15px' }}>
          <h3 style={{ margin: 0, color: '#043927', fontSize: '18px' }}>🌐 Real-Time Facility Resource Map</h3>
          <div>
            <label style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '14px', color: '#555' }}>Filter Sector:</label>
            <select value={activeDropdown} onChange={(e) => setActiveDropdown(e.target.value)} style={{ padding: '6px 12px', borderRadius: '4px', border: '1px solid #043927', fontWeight: 'bold', color: '#043927', outline: 'none' }}>
              <option value="All">🏥 All Wards Combined</option>
              <option value="ICU">ICU Ward</option>
              <option value="Emergency">Emergency Ward</option>
              <option value="Pediatrics">Pediatrics Ward</option>
              <option value="Surgical">Surgical Ward</option>
              <option value="General">General Ward</option>
            </select>
          </div>
        </div>

        {/* RESOURCE DISPLAY GRID DISPLAYING 'Bed 01' STRINGS ACCESSIBLY */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: '15px' }}>
          {visibleBeds.map((bed) => {
            let bg = '#eafaf1'; let tc = '#27ae60';
            if (bed.status === 'OCCUPIED') { bg = '#fdedec'; tc = '#c0392b'; }
            if (bed.status === 'CLEANING') { bg = '#fef5e7'; tc = '#d35400'; }

            return (
              <div key={bed.id} style={{ background: bg, border: `2px solid ${tc}`, borderRadius: '8px', height: '90px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', boxShadow: '0 2px 4px rgba(0,0,0,0.02)' }}>
                {/* Clean, high-visibility "Bed XX" rendering format */}
                <div style={{ fontSize: '15px', fontWeight: 'bold', color: '#2c3e50' }}>{bed.label}</div>
                <div style={{ fontSize: '11px', fontWeight: 'bold', color: tc, marginTop: '3px' }}>{bed.allocation}</div>
                <div style={{ fontSize: '9px', opacity: 0.6, color: '#333', textTransform: 'uppercase', marginTop: '2px' }}>{bed.status}</div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}