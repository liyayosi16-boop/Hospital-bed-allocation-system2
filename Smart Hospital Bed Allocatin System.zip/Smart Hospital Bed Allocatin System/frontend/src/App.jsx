
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import WardManagement from './pages/Wardmanagement';
import PatientDirectory from './pages/Patientdirectory';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        
        {/* Main Application Layout wrapper */}
        <Route path="/*" element={
          <div style={{ display: 'flex', height: '100vh', background: '#f5f7fb' }}>
            <Sidebar />
            <div style={{ flex: 1, padding: '30px', overflowY: 'auto' }}>
              <Routes>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/ward" element={<WardManagement />} />
                <Route path="/patients" element={<PatientDirectory />} />
                <Route path="*" element={<Navigate to="/dashboard" />} />
              </Routes>
            </div>
          </div>
        } />
      </Routes>
    </Router>
  );
}